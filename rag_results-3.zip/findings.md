# Findings (auto-generated from this run)

## 1. Without vs with reranking
- **fixed chunking:** P@5 0.667 → 0.733 (+0.066); R@5_norm 0.667 → 0.733 (+0.066); MRR 1.000 → 1.000 (+0.000)
- **recursive chunking:** P@5 0.733 → 0.733 (+0.000); R@5_norm 0.733 → 0.733 (+0.000); MRR 1.000 → 0.833 (-0.167)
- Average P@5 change from reranking: **+0.033**.

## 2. Chunking strategy 1 (fixed) vs strategy 2 (recursive)
- **rerank=no:** fixed → recursive: P@5 0.667 → 0.733 (+0.066); R@5_norm 0.667 → 0.733 (+0.066); MRR 1.000 → 1.000 (+0.000)
- **rerank=yes:** fixed → recursive: P@5 0.733 → 0.733 (+0.000); R@5_norm 0.733 → 0.733 (+0.000); MRR 1.000 → 0.833 (-0.167)
- Chunk statistics: fixed = 3520 chunks (92.6% end mid-sentence); recursive = 3481 chunks (2.4% end mid-sentence).

## 3. Without vs with conversational memory (follow-up turn M2)
- **rerank=no:** P@5 0.000 → 0.300 (+0.300); R@5_norm 0.000 → 0.300 (+0.300); MRR 0.000 → 1.000 (+1.000)
- **rerank=yes:** P@5 0.000 → 0.800 (+0.800); R@5_norm 0.000 → 0.800 (+0.800); MRR 0.000 → 1.000 (+1.000)
- Retrieval query without memory: `Which observations are used to measure it?`  
- Retrieval query with memory: `Which observations are used to measure it? (context: star formation galaxies)`

## Tables

|                      |   P@5 |   R@5 |   R@5_norm |   P@10 |   R@10 |   R@10_norm |   MRR |
|:---------------------|------:|------:|-----------:|-------:|-------:|------------:|------:|
| ('fixed', 'no')      | 0.667 | 0.062 |      0.667 |  0.633 |  0.112 |       0.633 | 1     |
| ('fixed', 'yes')     | 0.733 | 0.065 |      0.733 |  0.667 |  0.122 |       0.667 | 1     |
| ('recursive', 'no')  | 0.733 | 0.065 |      0.733 |  0.567 |  0.099 |       0.567 | 1     |
| ('recursive', 'yes') | 0.733 | 0.064 |      0.733 |  0.7   |  0.122 |       0.7   | 0.833 |


| turn   | chunking   | memory   | rerank   |   MRR |   n_relevant |   P@5 |   R@5 |   R@5_norm |   P@10 |   R@10 |   R@10_norm |
|:-------|:-----------|:---------|:---------|------:|-------------:|------:|------:|-----------:|-------:|-------:|------------:|
| M2     | fixed      | no       | no       |     0 |           33 |   0   | 0     |        0   |    0   |  0     |         0   |
| M2     | fixed      | no       | yes      |     0 |           33 |   0   | 0     |        0   |    0   |  0     |         0   |
| M2     | fixed      | yes      | no       |     1 |           33 |   0.4 | 0.061 |        0.4 |    0.4 |  0.121 |         0.4 |
| M2     | fixed      | yes      | yes      |     1 |           33 |   1   | 0.152 |        1   |    0.7 |  0.212 |         0.7 |
| M2     | recursive  | no       | no       |     0 |           33 |   0   | 0     |        0   |    0   |  0     |         0   |
| M2     | recursive  | no       | yes      |     0 |           33 |   0   | 0     |        0   |    0   |  0     |         0   |
| M2     | recursive  | yes      | no       |     1 |           33 |   0.2 | 0.03  |        0.2 |    0.1 |  0.03  |         0.1 |
| M2     | recursive  | yes      | yes      |     1 |           33 |   0.6 | 0.091 |        0.6 |    0.6 |  0.182 |         0.6 |